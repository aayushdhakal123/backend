const express=require("express");
const bodyParser=require("body-parser");
const ejs=require("ejs");
const _=require("lodash");
const mongoose=require("mongoose");

const homeStartingContent = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo harum architecto reprehenderit, rerum maiores";
const aboutContent="Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo harum architecto reprehenderit, rerum maiores";
const contactContent="Lorem ipsum dolor sit amet consectetur adipisicing elit. Illo harum architecto reprehenderit, rerum maiores";


const app=express();
let para;

app.set('view engine','ejs');

app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));
const uri = "mongodb+srv://aayushdhakal005:psycho256@cluster0.ko9gpz4.mongodb.net/blogDB?retryWrites=true&w=majority";

mongoose.connect(uri,
{
    useNewUrlParser :true
});

const postSchema=
{
    title:String,
    content:String
};

const Post=mongoose.model("Post",postSchema);

app.get("/", async function (req, res) {
    try {
      const posts = await Post.find({});
      res.render("home", { homec: homeStartingContent, posts: posts });
    } catch (err) {
      console.error(err);
      res.status(500).send("Internal Server Error");
    }
  });
  
  
app.get("/about", function(req, res)
{
    res.render("about",{aboutc:aboutContent});
});
app.get("/contact", function(req, res)
{
    res.render("contact",{contactc:contactContent});
});
app.get("/compose", function(req, res)
{
    res.render("compose");
});
app.get("/posts/:postName", async function (req, res) {
    const requestedTitle = _.lowerCase(req.params.postName);
  
    try {
      const post = await Post.findOne({ title: requestedTitle });
      if (post) {
        res.render("post", {
          posttile: post.title,   
          postbody: post.content   
        });
      } else {
        res.status(404).send("Post not found");
      }
    } catch (err) {
      console.error(err);
      res.status(500).send("Internal Server Error");
    }
  });
  
  
  app.post("/compose", async function (req, res) {
    try {
      const post = new Post({
        title: req.body.blogtitle,
        content: req.body.blogbody
      });
      await post.save(); 
      res.redirect("/");
    } catch (err) {
      console.error(err);
      res.status(500).send("Internal Server Error");
    }
  });
  

app.listen(3000, function(req, res)
{
    console.log("Server is running at port 3000");
})